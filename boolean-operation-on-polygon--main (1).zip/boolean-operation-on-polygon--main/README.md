# boolean-operation-on-polygon-
The input files contain coordinates of polygons given in clockwise direction.
Example : 
-4,0;
-4,2;
-3,4;
0,4;
1,2;
0,-1;
-2,-2;

The image files are the output for the given input files. 
Area.py file calculates area of the input1 polygon.

![Area](https://user-images.githubusercontent.com/62550460/122209452-2aaead00-cec2-11eb-801e-912646037c37.png)

 Operations.py performs boolean operations on the polygons input1 and input2
 
![AminusB](https://user-images.githubusercontent.com/62550460/122209450-297d8000-cec2-11eb-8fc6-ee1687d82aa2.png)
![Intersection](https://user-images.githubusercontent.com/62550460/122209457-2b474380-cec2-11eb-8aaf-11c45928cd51.png)
